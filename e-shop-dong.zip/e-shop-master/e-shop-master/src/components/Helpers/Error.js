import React from "react";
const Error = () => {
  return (
    <div style={{ textAlign: "center" }} className="container container-center">
      <h2>error</h2>
    </div>
  );
};

export default Error;
