### <p align="center"> <a href="https://e-shopp.netlify.app/" target="_blank" >Link demo</a> <p>

### <p align="left"> <a href="https://www.behance.net/gallery/86012235/eCommerce-Free-UI-Kit" target="_blank">Link design</a> <p>

## Tech

- React JS
- Hooks
- Context API
- Styled Components
- React Router
- React Icons
