<?php
////$_SESSION['login']=true;//////
if ($_SESSION['login']==false)
{
header("location:index.php");
}
?>

<?php 

$result = mysql_query("SELECT * FROM menu order by sapxep");
while($rowmenu = mysql_fetch_array($result))
  {
?>

<a id="leftmenu" href="?go=cat&id=<?php echo $rowmenu['id']?>&ten=<?php echo $rowmenu['ten']?>.htm"> 
<div id="textleftmenu"><?php echo $rowmenu['ten'] ?> </div> 
</a>

<?php
}
?>
