<?php
include ("dbconnect.php");
$id_dm=$_GET['id_dm'];
mysql_query("DELETE FROM danhmuc WHERE id_dm='$id_dm'");
echo "<script>alert('b?n d� x�a th�nh c�ng');location='admin.php?admin=danhmuc'; </script>"
?>