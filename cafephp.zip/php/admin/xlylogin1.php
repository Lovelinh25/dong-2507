<?php
ob_start();
?>
<?php include("../dbconnect.php")?>
<?php
$u=$_POST['hoten'];
$p=$_POST['matkhau'];
echo $u.$p."<br>";
$result = mysql_query("SELECT * FROM login where hoten='admin' and matkhau='admin'");
while($rowcat = mysql_fetch_array($result))
  {
		 if ($rowcat)   
		           {
				   echo "false";
				   header("location:admin.php");
				  break;
  				   
				   }

				   echo "true";
				   break;
   				   				   
		 
   }
   ob_end_flush();
?>