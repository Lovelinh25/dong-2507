<?php include("dbconnect.php") ?>
<?php
$danhmuc = $_POST["danhmuc"];
$result = mysql_query("INSERT INTO danhmuc (danhmuc) VALUES ('$danhmuc')");
echo "<script>alert('b?n d� th�m th�nh c�ng');location='admin.php?admin=danhmuc'; </script>"
?>