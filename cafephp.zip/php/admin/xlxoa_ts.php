<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <?php
      $id_ts=$_GET['id_ts'];
      include ("dbconnect.php");
      $query="Delete from thoisu where id_ts='$id_ts'";
	  mysql_query($query); 
echo "<script> alert('bạn dã xóa thành công');location='admin.php?admin=xoa_ts'; </script>"
	  ?>
	  