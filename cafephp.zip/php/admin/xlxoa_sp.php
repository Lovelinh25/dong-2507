  <?php
      $id_sp=$_GET['id_sp'];
      include ("dbconnect.php");
      $query="Delete from sanpham where id_sp='$id_sp'";
	  mysql_query($query); 
echo "<script> alert('b?n d� xoa th�nh c�ng');location='admin.php?admin=xoa_sp'; </script>"
	  ?>
	  