<form action="upload.php" method="post"
 enctype="multipart/form-data">
 Nhap anh : <input type="file" name="a">
 <br>
 <input type="submit" value="Upload"> 
  </form>