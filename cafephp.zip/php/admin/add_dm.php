<html>
<?php include ("dbconnect.php")?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>web</title>
</head>
<body>

<p align="center">&nbsp;</p>
<p align="center"><b><font size="6" color="#800000"><u>THÊM DANH MUC</u></font></b></p>
<p align="center">&nbsp;</p>
<form method="POST" action="xladd_dm.php">
  <p align="center">Them moi danh muc <input type="text" name="danhmuc" size="49" value=""></p>
  <p align="center"><input type="submit" value="Thêm" name="Submit"><input type="reset" value="Làm Lại" name="reset"></p>
</form>
<p></p>

</body>