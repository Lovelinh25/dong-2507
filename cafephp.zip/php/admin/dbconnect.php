<?php
$ketnoi= mysql_connect("localhost","root","");
if(!$ketnoi)
	{
	die('could not connect :'.mysql_error());
	}
mysql_select_db("database",$ketnoi);
@mysql_query("SET NAMES utf8");
?>