<?php
include ("dbconnect.php");
$id=$_GET['id'];
mysql_query("DELETE FROM login WHERE id='$id'");
echo "<script>alert('bạn đã xóa thành công');location='admin.php?admin=quanly'; </script>"
?>