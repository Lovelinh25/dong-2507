<?php
include ("dbconnect.php");
$id_dm=$_GET['id_dm'];
$danhmuc= $_POST['danhmuc'];
$result = mysql_query("UPDATE danhmuc SET danhmuc='$danhmuc' where id_dm='$id_dm'" );

echo "<script>alert('b?n d� s?a th�nh c�ng');location='admin.php?admin=danhmuc'; </script>"

?>
