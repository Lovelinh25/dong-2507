<?php include "dbconnect.php"?>
<table>
    <tr>
        <?php
        $query="SELECT * FROM sanpham where hienthi='1' order by id_sp desc";
        $kq=mysql_query($query) or die(error());
        $i=1;
        echo "<table width='700' border='0' cellspacing='0px' cellpadding='0px'>";
        echo"<tr>";
        while($r=mysql_fetch_array($kq))
        {
            echo "<td width='230' align='center' bgcolor='#ffffff'><img src=".$r['hinhanh']." width='150' height='200'>
            <br><a href='?go=detail_sp&id=".$r['id_sp']."' id='text_lq'>".$r['tensp']."</a><br><b>gia:</b>
            ".$r['gia'].".000 VND</td>";
            if($i%3==0){
                echo"</tr><tr>";
            }
            $i=$i+1;
        }
        
        ?>
    </tr>
</table>