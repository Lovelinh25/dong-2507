
<?php 
session_start();
include ("dbconnect.php")
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="vi">
<title>ebooks</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<center>
<div id="main">
	<div id="header"><?php include ("header.php")?></div>
	<div id="center"><?php include("url.php") ?></div>
	<div id="footer"><?php include ("footer.php")?></div>
</div>
</center>
</body>
</html>
