<!DOCTYPE html>
<?php iclude("dbconnect.php")?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
<div class="w3-container">
<div class="w3-row-padding">
    <?php
    $query="SELECT * FROM sanpham";
    $kq=mysql_query($query) or die(error());
    while($mg=mysql_fetch_array($kq))
        {
    ?>
     <div class="w3-container w3-third">
        <img src="<?php echo $mg['hinhanh']?>"style="width: 100%;cursor:pointer"
        onclick="onclick(this)"class="w3-hover-opacity">
        <br>
        <p style="color: red;"><?php echo $mg['tensp']?></p>
        </div>
        <?php
        }
        ?>
        </div>
</body>
</html>