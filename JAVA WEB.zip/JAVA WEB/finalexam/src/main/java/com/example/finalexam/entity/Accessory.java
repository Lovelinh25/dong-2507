package com.example.finalexam.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.context.annotation.Primary;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "accessory")
public class Accessory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    private String licencePlate;
    private Date repairDate;
    private String name;
    private String price;
    private String statusDamaged;
    private String repairStatus;
    @ManyToOne(fetch = FetchType.LAZY)
    private Accessory accessory;


}
