package com.example.finalexam.Repository;

import com.example.finalexam.entity.Accessory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccesoryRepository extends JpaRepository<Accessory, Long> {

    List<Accessory> findByLicencePlate(String licensePlate);
}
