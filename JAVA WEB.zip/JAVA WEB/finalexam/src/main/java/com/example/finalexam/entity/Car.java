package com.example.finalexam.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "car")

public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JoinColumn(name = "accessory_licencePlate" )

    private String licencePlate;
    @JoinColumn (name = "accessory_repairDate")
    private Date repairDate;
    private String customerName;
    private String Maker;
   @OneToMany(cascade = CascadeType.ALL,mappedBy = "Car",orphanRemoval = true)
    private List<Car> cars = new ArrayList<>();

}
