package com.example.finalexam.Service;

public interface CarService {
}
