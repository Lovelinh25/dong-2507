public class GirlFriend {

    private Outfit outfit;

    public GirlFriend(Outfit outfit) {
        this.outfit = outfit;
    }
}
