public class Dress implements Outfit{
    @Override
    public void wear() {
        System.out.println("You are wearing dress");
    }
}
