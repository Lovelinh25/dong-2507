public interface Outfit {
    void wear();
}
