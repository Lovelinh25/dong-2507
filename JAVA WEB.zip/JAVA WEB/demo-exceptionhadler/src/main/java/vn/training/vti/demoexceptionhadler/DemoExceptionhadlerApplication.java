package vn.training.vti.demoexceptionhadler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoExceptionhadlerApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoExceptionhadlerApplication.class, args);
    }

}
