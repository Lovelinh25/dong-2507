package vn.training.vti.i18demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class I18DemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
