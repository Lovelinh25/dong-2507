package vn.training.vti.i18demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class I18DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(I18DemoApplication.class, args);
    }

}
