1. Tạo project cùng với các dependencies:
    - JPA Stater
    - Lombok
    - H2
    - JUnit5
    - AssertJ
2. Bổ xung cấu hình vào application.properties
3. Tạo thư mục model có các entity Car, Employee
4. Tạo các bản ghi từ Mockaroo
5. Tạo repositories cho các entity Car,Employee
6. Tạo unit test kiểm tra các truy vấn trong JPA Data ở repository
7. Sinh viên thực hành thêm các entity khác
