package vn.vti.jsondemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
