package com.example.demowebsit.Controller;

import org.springframework.web.bind.annotation.GetMapping;

public class DemoController {
    @GetMapping("/demo")
    public String demo(){
        return
    }
}
