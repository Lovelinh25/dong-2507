package com.example.demowebsit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebsitApplicationTests {

	@Test
	void contextLoads() {
	}

}
