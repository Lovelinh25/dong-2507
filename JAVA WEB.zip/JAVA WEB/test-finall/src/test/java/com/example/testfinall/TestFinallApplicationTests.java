package com.example.testfinall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestFinallApplicationTests {

    @Test
    void contextLoads() {
    }

}
