package com.example.testfinall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestFinallApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestFinallApplication.class, args);
    }

}
