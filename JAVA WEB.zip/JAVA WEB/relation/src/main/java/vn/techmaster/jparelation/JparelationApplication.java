package vn.techmaster.jparelation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JparelationApplication {

    public static void main(String[] args) {
        SpringApplication.run(JparelationApplication.class, args);
    }

}
