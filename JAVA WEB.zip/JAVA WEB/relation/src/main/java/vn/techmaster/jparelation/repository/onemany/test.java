package vn.techmaster.jparelation.repository.onemany;

public class test {
}
