package vn.vti.training.fileuploaddownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileuploaddownloadApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileuploaddownloadApplication.class, args);
    }

}
