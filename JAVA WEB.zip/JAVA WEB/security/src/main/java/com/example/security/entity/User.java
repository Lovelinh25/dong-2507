package com.example.security.entity;
@Data
public class User {
}
