package com.vti.training.jparelation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaRelationApplication {

    public static void main(String[] args) {
        SpringApplication.run(JpaRelationApplication.class, args);
    }

}
