package com.vti.training.jparelation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRelationApplicationTests {

    @Test
    void contextLoads() {
    }

}
