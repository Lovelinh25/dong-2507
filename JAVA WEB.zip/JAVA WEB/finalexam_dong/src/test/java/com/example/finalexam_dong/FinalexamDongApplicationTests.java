package com.example.finalexam_dong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalexamDongApplicationTests {

    @Test
    void contextLoads() {
    }

}
