package com.example.finalexam_dong.controller;

import com.example.finalexam_dong.entity.Car;
import com.example.finalexam_dong.service.CarSeviceImp;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class CarController {
    private final CarSeviceImp service;


    @GetMapping
    public ResponseEntity<?> getAll(){
        return new ResponseEntity<>(service.listAll(), HttpStatus.OK);
    }






    @PostMapping
    public ResponseEntity<?> addCar(@RequestBody Car car){
        return new ResponseEntity<>(service.saveCar(car),HttpStatus.CREATED);
    }

    @PutMapping("/employee/{licensePlate}")
    public ResponseEntity<?> updateCar(@PathVariable String licensePlate, @RequestBody Car car){
        return new ResponseEntity<>(service.updateCar(licensePlate,car),HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable String licensePlate){
        service.deleteCar(licensePlate);
        return ResponseEntity.ok().body("Delete successfully");
    }
}
