package com.example.finalexam_dong.repository;

import com.example.finalexam_dong.entity.Accessory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccessoryRepository extends JpaRepository<Accessory, Long> {
}
