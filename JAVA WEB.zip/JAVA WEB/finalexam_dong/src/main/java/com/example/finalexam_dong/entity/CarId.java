package com.example.finalexam_dong.entity;

import jakarta.persistence.Embedded;
import lombok.*;

import java.io.Serializable;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CarId implements Serializable {
    @Embedded
    private String licensePlate;
    private String repairDate;
}
