package com.example.finalexam_dong.controller;

import com.example.finalexam_dong.entity.Accessory;
import com.example.finalexam_dong.service.AccessoryServiceImp;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/accessory")
@RequiredArgsConstructor
public class AccessoryController {
    private final AccessoryServiceImp service;

    @GetMapping
    public ResponseEntity<?> getAll() {
        return new ResponseEntity<>(service.listAllAc(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable("id") Long id) {
        return new ResponseEntity<>(service.getAccessory(id), HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<?> addAccessory(@RequestBody Accessory accessory) {
        return new ResponseEntity<>(service.saveAccessory(accessory), HttpStatus.CREATED);
    }

    @PutMapping("/accessory/{id}")
    public ResponseEntity<?> updateAccessory(@PathVariable Long id, @RequestBody Accessory accessory) {
        return new ResponseEntity<>(service.updateAccessory(id, accessory), HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteAccessory(@PathVariable Long id) {
        service.deleteAccessory(id);
        return ResponseEntity.ok().body("Delete successfully");
    }
}