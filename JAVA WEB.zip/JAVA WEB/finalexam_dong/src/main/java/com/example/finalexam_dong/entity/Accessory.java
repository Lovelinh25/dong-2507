package com.example.finalexam_dong.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Accessory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;


    private float price;

    private boolean statusDamaged;

    private String repairStatus;
    @ManyToOne(fetch = FetchType.LAZY)

    @JoinColumn(name = "car_licensePlate")
    @JoinColumn(name = "car_repairDate")
//    @JoinColumn(name = "car_repairDate")
private Car car;
}
