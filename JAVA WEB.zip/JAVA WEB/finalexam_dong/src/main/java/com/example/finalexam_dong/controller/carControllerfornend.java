package com.example.finalexam_dong.controller;

import com.example.finalexam_dong.entity.Car;
import com.example.finalexam_dong.service.CarSeviceImp;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
//@RequiredArgsConstructor
public class carControllerfornend {
    private final CarSeviceImp repo;

    public carControllerfornend(CarSeviceImp repo) {
        this.repo = repo;
    }

    @GetMapping("/car")
    public String home(){
        return "index";
    }
    @GetMapping("/listAll")
    public String getAll(Model model, @RequestParam(value = "direction",required = false)String direction){
        if(direction==null){
            model.addAttribute("cars",repo.listAll());
        }else{
            List<Car> cars = (List<Car>) repo.sortBy(direction);
            model.addAttribute("cars",cars);
        }
        return "list";
    }


    @GetMapping("/create")
    public String createCustomer(Model model){
        model.addAttribute("car",new Car());
        return "CarForm";
    }

    @PostMapping("/post")
    public String postInfo( @ModelAttribute("car") Car car, BindingResult result, Model model) {
        if (!result.hasErrors()) {
            if(car.getLicensePlate()!=null){
                repo.updateCar(car.getLicensePlate(), car);
            }else{
                repo.saveCar(car);
            }
            model.addAttribute("cars", repo.listAll());
            return "redirect:/listAll";
        }
        return "CarForm";
    }

    @GetMapping("/edit/{licensePlate}")
    public String editCar(@PathVariable("licensePlate") String licensePlate, Model model) {
        Car car = repo.findBylicensePlate(licensePlate);
        model.addAttribute("car",car);
        return "CarForm";
    }

    @GetMapping("/delete/{licensePlate}")
    public String deleteCar(@PathVariable("licensePlate") String LicensePlate, Model model){
        repo.deleteCar(LicensePlate);
        model.addAttribute("customers",repo.listAll());
        return "redirect:/listAll";
    }
}
