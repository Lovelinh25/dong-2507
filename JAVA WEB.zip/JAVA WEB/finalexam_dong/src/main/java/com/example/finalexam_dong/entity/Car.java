package com.example.finalexam_dong.entity;

import jakarta.persistence.*;
import lombok.*;


import java.util.List;
import java.util.Set;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@IdClass(CarId.class)
public class Car {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//
//private Long id;

    @Id
    private String licensePlate;
    @Id
    private String repairDate;

    private String customerName;
    private String catalog;
    private String carMaker;

}
