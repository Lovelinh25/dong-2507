package com.example.finalexam_dong.service;

import com.example.finalexam_dong.entity.Accessory;

import java.util.List;

public interface AccessorySevice {
    Accessory saveAccessory(Accessory accessory);
    List<Accessory> listAllAc();
    Accessory getAccessory(Long id);
    Accessory updateAccessory(Long id, Accessory accessory);

    Accessory sortBy(String sorting);


    Accessory findById(Long id);

    void deleteAccessory(Long id);
}
