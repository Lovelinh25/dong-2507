package com.example.finalexam_dong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalexamDongApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalexamDongApplication.class, args);
    }

}
