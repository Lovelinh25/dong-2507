package com.example.finalexam_dong.controller;

import com.example.finalexam_dong.entity.Accessory;
import com.example.finalexam_dong.service.AccessoryServiceImp;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class accessoryContronllerFondend {
    private final AccessoryServiceImp repo;

    public accessoryContronllerFondend(AccessoryServiceImp repo) {
        this.repo = repo;
    }
    @GetMapping
    public String home(){
        return "index";
    }
    @GetMapping("/listAllAc")
    public String getAll(Model model, @RequestParam(value = "direction",required = false)String direction){
        if(direction==null){
            model.addAttribute("accs",repo.listAllAc());
        }else{
            List<Accessory> accs = (List<Accessory>) repo.sortBy(direction);
            model.addAttribute("accs",accs);
        }
        return "listAccessory";
    }




    @GetMapping("/createAc")
    public String createCustomer(Model model){
        model.addAttribute("accs",new Accessory());
        return "AccessoryForm";
    }

    @PostMapping("/postAc")
    public String postInfo(@ModelAttribute("accs") Accessory accessory, BindingResult result, Model model) {
        if (!result.hasErrors()) {
            if(accessory.getId()!=null){
                repo.updateAccessory(accessory.getId(), accessory);
            }else{
                repo.saveAccessory(accessory);
            }
            model.addAttribute("accs", repo.listAllAc());
            return "redirect:/listAllAc";
        }
        return "AccessoryForm";
    }

    @GetMapping("/edit/{id}")
    public String editPerson(@PathVariable("id") Long id, Model model) {
        Accessory accessory = repo.findById(id);
        model.addAttribute("accs",accessory);
        return "AccessoryForm";
    }

    @GetMapping("/delete/{id}")
    public String deletePerson(@PathVariable("id") Long id, Model model){
        repo.deleteAccessory(id);
        model.addAttribute("customers",repo.listAllAc());
        return "redirect:/listAllAc";
    }
}
