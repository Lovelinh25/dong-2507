package com.example.finalexam_dong.service;

import com.example.finalexam_dong.entity.Accessory;
import com.example.finalexam_dong.repository.AccessoryRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AccessoryServiceImp implements AccessorySevice{
    private final AccessoryRepository accRepo;

    public AccessoryServiceImp(AccessoryRepository accRepo) {
        this.accRepo = accRepo;
    }

    @Override
    public Accessory saveAccessory(Accessory accessory) {
        return accRepo.save(accessory);
    }

    @Override
    public List<Accessory> listAllAc() {
        return accRepo.findAll();
    }

    @Override
    public Accessory getAccessory(Long id) {
        return accRepo.findById(id).orElse(null);
    }
    @Override
    public Accessory sortBy(String sorting) {
        return null;
    }

    @Override
    public Accessory updateAccessory(Long id, Accessory accessory) {
        Accessory exits = getAccessory(id);
        exits.setName(accessory.getName());
        exits.setPrice(accessory.getPrice());
        exits.setRepairStatus(accessory.getRepairStatus());
        exits.setStatusDamaged(accessory.isStatusDamaged());

        return accRepo.save(exits);
    }

    @Override
    public Accessory findById(Long id) {
        Optional<Accessory> opacc = accRepo.findById(id);
        if(opacc.isPresent()){
            return opacc.get();
        }else return null;
    }



    @Override
    public void deleteAccessory(Long id) {
        Accessory exits =getAccessory(id);
        accRepo.delete(exits);
    }
}
