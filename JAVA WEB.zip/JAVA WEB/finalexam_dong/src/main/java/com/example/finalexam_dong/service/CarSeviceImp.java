package com.example.finalexam_dong.service;

import com.example.finalexam_dong.entity.Accessory;
import com.example.finalexam_dong.entity.Car;
import com.example.finalexam_dong.repository.CarRepository;


import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CarSeviceImp implements CarService{
    private  final CarRepository carRepo;
    private List<Car> cars = new ArrayList<>();


    public CarSeviceImp(CarRepository carRepo) {
        this.carRepo = carRepo;
    }

    @Override
    public Car saveCar(Car car) {
        return carRepo.save(car);
    }

    @Override
    public List<Car> listAll() {
        return carRepo.findAll();
    }

    @Override
    public Car findBylicensePlate(String licensePlate) {
        Optional<Car> opcar = carRepo.findById(licensePlate);
        if(opcar.isPresent()){
            return opcar.get();
        }else return null;
    }

    @Override
    public Car sortBy(String sorting) {
        return null;
    }




    @Override
    public Car updateCar(String licensePlate, Car car) {
        Car exits = carRepo.findById(licensePlate).get();
        exits.setRepairDate(car.getRepairDate());
        exits.setCustomerName(car.getCustomerName());
        exits.setCatalog(car.getCatalog());
        exits.setCarMaker(car.getCarMaker());
        carRepo.save(exits);
        return exits;
    }
    @Override
    public Car getEmployeeBylicensePlate(String licensePlate) {

        return carRepo.findById(licensePlate).orElse(null);
    }
    @Override
    public void deleteCar(String licensePlate) {
        Car exits = getEmployeeBylicensePlate(licensePlate);
        carRepo.delete(exits);
    }

}
