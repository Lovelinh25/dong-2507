package com.example.finalexam_dong.service;

import com.example.finalexam_dong.entity.Car;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CarService {
    List<Car> listAll();
    Car saveCar(Car car);
    Car findBylicensePlate(String licensePlate);
    Car getEmployeeBylicensePlate(String licensePlate);
    Car sortBy(String licensePlate);
    Car updateCar(String licensePlate, Car car);

    void deleteCar(String licensePlate);

}
