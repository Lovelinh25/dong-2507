package com.example.demoinjection;

public interface SortAlgorithm {
    int[] sort(int[] numbers);
}
